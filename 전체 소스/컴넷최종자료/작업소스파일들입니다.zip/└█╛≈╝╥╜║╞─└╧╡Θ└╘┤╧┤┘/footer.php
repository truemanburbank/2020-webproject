<!doctype html>
<html>
<link rel ="stylesheet" href="/css/footer.css">

<footer class="footer-distributed">

			<div class="footer-left">

				<p class="footer-links">
					<a class="link-1" href="http://cs.gnu.ac.kr/cs/main.do">ComNet From Gyeongsang National University Computer Science</a>

				</p>

		<p>ComNet &copy; 2020, 염혜윤, 정수진, 이채연, 김동현, 김선우, 박미성</p>
	</div>

</footer>
</div>
</html>